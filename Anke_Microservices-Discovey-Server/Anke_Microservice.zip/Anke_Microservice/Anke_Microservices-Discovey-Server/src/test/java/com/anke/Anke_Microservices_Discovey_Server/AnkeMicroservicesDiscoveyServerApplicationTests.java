package com.anke.Anke_Microservices_Discovey_Server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnkeMicroservicesDiscoveyServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
