package com.anke.Anke_Microservices_Config_Server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnkeMicroservicesConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
