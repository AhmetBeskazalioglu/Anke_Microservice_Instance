package com.anke.Anke_Microservices_ShoppingCart_Service;


import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class AnkeMicroservicesShoppingCartServiceServiceApplicationTests {

	@Test
    public void contextLoads() {
	}

}
