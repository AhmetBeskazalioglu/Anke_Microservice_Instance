package com.anke.Anke_Microservices_Product_Service;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class AnkeMicroservicesProductServiceApplicationTests {

	@Test
    public void contextLoads() {
	}

}
